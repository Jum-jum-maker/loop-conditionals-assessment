

// Assignments

// 1. Using for loop to print out all even numbers between 0-100

// 2. Random generation of these array ["love", "loyalty", "Respect"]

for(let i =2; i<=100; i+=2)
console.log(i)