let Button=document.getElementById("btn")
let Output=document.getElementById("output")

Button.addEventListener("click", function(){
    let array=["Loyalty ", "Love ", "Respect "]
    Output.innerHTML=""

    for(let i=0; i<array.length; i++){;
    const result=array[i]
    Output.innerHTML +=result
    }
});


